package SwagLabs.cucumber.runner;

public class runLoginFailed {
}
