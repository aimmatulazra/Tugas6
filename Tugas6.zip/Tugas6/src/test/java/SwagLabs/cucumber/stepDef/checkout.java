package SwagLabs;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.util.concurrent.TimeUnit;

public class checkout {
    @org.junit.Test
    public void Add_to_cart(){
        WebDriver driver;
        String baseUrl = "https://www.saucedemo.com/";

        WebDriverManager.edgedriver().setup();

        //Open Page
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get(baseUrl);

        String loginPageAssert = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]")).getText();
        Assert.assertEquals(loginPageAssert, "Swag Labs");

        //Input username
        driver.findElement(By.id("user-name")).sendKeys("standard_user");

        //Input password
        driver.findElement(By.id("password")).sendKeys("secret_sauce");

        //Click Login
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();

        //Assertion
        String successPageAssert = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[1]/div[2]/div")).getText();
        Assert.assertEquals(successPageAssert, "Swag Labs");

        //click product
        driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).click();

        //click button add to cart
        driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();

        //click shopping cart
        driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();

        //Assertion Your Cart
        String successAddToCart = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        Assert.assertEquals(successAddToCart, "Your Cart");

        //click checkout
        driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();

        //Input First Name
        driver.findElement(By.id("first-name")).sendKeys("Aimmatul");

        //Input Last Name
        driver.findElement(By.id("last-name")).sendKeys("Azra");

        //Input ZIP Code
        driver.findElement(By.id("postal-code")).sendKeys("40134");

        //click button continue
        driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();

        //Assertion Checkout Review
        String checkoutReview = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        Assert.assertEquals(checkoutReview, "Checkout: Overview");

        //click button finish
        driver.findElement(By.xpath("//*[@id=\"finish\"]")).click();

        //Assertion Checkout Complete
        String checkoutComplete = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText();
        Assert.assertEquals(checkoutComplete, "Checkout: Complete!");

    }
}
