package SwagLabs.cucumber.stepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.util.concurrent.TimeUnit;

public class Login {
    WebDriver driver;
    String baseUrl = "https://www.saucedemo.com/";

    @Given("Login page Swag Labs")
    public void loginPageSwagLabs() {
        WebDriverManager.edgedriver().setup();
        //Open Page
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.get(baseUrl);

        String loginPageAssert = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]")).getText();
        Assert.assertEquals(loginPageAssert, "Swag Labs");
        throw new io.cucumber.java.PendingException();
    }


    @When("Input username")
    public void inputUsername(){
        //Input username
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
    }

    @And("Input password")
    public void inputPassword(){
        //Input password
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
    }

    @And("Click login button")
    public void ClickLoginButton(){
        //Click Login
        driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
    }

    @Then("User in Swag Labs page")
    public void SwagLabsPage(){
        //Assertion
        String successPageAssert = driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[1]/div[2]/div")).getText();
        Assert.assertEquals(successPageAssert, "Swag Labs");
    }

    @Then("Input invalid password")
    public void inputInvalidPassword() {
        //Input wrong password
        driver.findElement(By.id("password")).sendKeys("wrong_password");
    }

    @Then("User get error message")
    public void userGetErrorMessage(){
        //Assertion
        String failedPageAssert = driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
        Assert.assertEquals(failedPageAssert, "Epic sadface: Username and password do not match any user in this service");
    }



}
